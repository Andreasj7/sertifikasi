-- AlterTable
ALTER TABLE `approval` MODIFY `is_approved` BOOLEAN NOT NULL DEFAULT false;
