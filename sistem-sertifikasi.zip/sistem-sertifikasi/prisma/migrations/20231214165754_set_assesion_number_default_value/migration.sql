-- AlterTable
ALTER TABLE `assesmentimplementation` MODIFY `assesionNumber` INTEGER NOT NULL DEFAULT 0;
