-- AlterTable
ALTER TABLE `sptassesor` MODIFY `noSptAssesor` VARCHAR(191) NULL,
    MODIFY `assesorDate` VARCHAR(191) NULL;
