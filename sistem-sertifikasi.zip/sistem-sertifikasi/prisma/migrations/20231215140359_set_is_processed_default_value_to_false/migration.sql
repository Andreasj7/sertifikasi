-- AlterTable
ALTER TABLE `asstestresult` MODIFY `isProcessed` BOOLEAN NOT NULL DEFAULT false;
