-- AlterTable
ALTER TABLE `tukconfirmation` ADD COLUMN `description` VARCHAR(191) NULL;
